<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DANH SÁCH SẢN PHẨM - Đinh Quốc Đạt</title>
</head>
<body>
    <?php 
        include("ketnoi-dinhquocdat.php");
        $sql_dqd = "SELECT * FROM bang_dinhquocdat WHERE 1 =1 ";
        $result_dqd = $conn_dqd->query($sql_dqd);
    ?>
    <?php
        if(isset($_GET["id"])){
            $sql_dqd_delete = "DELETE FROM bang_dinhquocdat WHERE MA_2210900139='" . $_GET["id"] . "'";
            if($conn_dqd->query($sql_dqd_delete)){
                header("location:sanpham-list-dinhquocdat.php");
            }
        }
    ?>
    <header>
        <h1> Danh sách hiển thị sản phẩm -Đinh Quốc Đạt-2210900139</h1>
    </header>
    <section>
        <a href="sanpham-add-dinhquocdat.php">thêm mới</a>
        <table width="100%" border="1px">
            <thead>
                <tr>
                    <th>Stt</th>
                    <th>Mã</th>
                    <th>Tên</th>
                    <th>Sl</th>
                    <th>đơn giá</th>
                    <th>ảnh</th>
                    <th>Trạng thái</th>
                    <th>Chức năng</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                        $stt_dqd=0;
                        while($row_dqd = $result_dqd->fetch_array()){
                            $stt_dqd ++;
                ?>
                    <tr>
                        <td><?php echo $stt_dqd; ?></td>
                        <td><?php echo $row_dqd["MA_2210900139"]; ?></td>
                        <td><?php echo $row_dqd["TEN_2210900139"]; ?></td>
                        <td><?php echo $row_dqd["SL_2210900139"]; ?></td>
                        <td><?php echo $row_dqd["DG_2210900139"]; ?></td>
                        <td><?php echo $row_dqd["ANH_2210900139"]; ?></td>
                        <td><?php echo 
                                $row_dqd["TRANGTHAI_2210900139"]==true?" yêu em":"ẩn";  ?></td>
                        <td>
                            <a href="sanpham-edit-dinhquocdat.php?id=<?php echo $row_dqd["MA_2210900139"]; ?>"> sửa</a> 
                            |
                            <a href="sanpham-list-dinhquocdat.php?id=<?php echo $row_dqd["MA_2210900139"]; ?>"> xóa</a>
                        </td>
                        
                    </tr>
                <?php 
                        }
                ?>
            </tbody>
        </table>
    </section>

</body>
</html>