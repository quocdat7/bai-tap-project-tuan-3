<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thêm mới thông tin sản phẩm</title>
    <link rel="stylesheet" href="style.css"/>
</head>
<body>
    <?php
        include("ketnoi-dinhquocdat.php");
        $sql_pb_DQD = "SELECT * FROM sanpham_DQD  WHERE 1=1";
        $res_pb_DQD = $conn_DQD->query($sql_pb_DQD);
        if(isset($_POST["btnSubmit_DQD"])){
            $SPID_DQD = $_POST["SPID_DQD"];
            $TESP_DQD = $_POST["TESP_DQD"];
            $SOLUONG_DQD = $_POST["SOLUONG_DQD"];
            $GIAMUA_DQD = $_POST["GIAMUA_DQD"];
            $GIABAN_DQD = $_POST["GIABAN_DQD"];
            $TRANGTHAI_DQD = $_POST["TRANGTHAI_DQD"];
            $MADM_DQD = $_POST["MADM_DQD"];
            $sql_check_DQD = "SELECT SPID_DQD FROM sanpham_DQD WHERE SPID_DQD = 'SPID_DQD' ";
            $res_check_DQD = $conn_DQD->query($sql_check_DQD);
            if($res_check_DQD->num_rows>0){
                $error_message_DQD="Lỗi trùng khóa chính.";
            }
            $sql_insert_DQD = "INSERT INTO sanpham_DQD ('SPID_DQD', 'TESP_DQD', 'SOLUONG_DQD','GIAMUA_DQD', 'GIABAN_DQD', 'TRANGTHAI_DQD', 'MADM_DQD')";
            $sql_insert_DQD.="VALUES ('$SPID_DQD','$TESP_DQD','$SOLUONG_DQD','$GIAMUA_DQD','$GIABAN_DQD','$TRANGTHAI_DQD','$MADM_DQD');";
            if($conn_DQD->query($sql_insert_DQD)){
                header("Location: sanpham-lisT-DQD.php"); 
            }else{
                $error_message_DQD="Lỗi thêm mới". mysqli_error($conn_DQD);
            }
        }
        ?>
    <section class="container">
        <h1>Thêm mới thông tin sản phẩm</h1>
        <form name="frm_DQD" method="post" action="">
            <table border="1" width="100%" cellspacing="5" cellpadding="5">
                <tbody>
                    <tr>
                        <td>Mã</td>
                        <td>
                            <input type="text" name="SPID_DQD" id="SPID_DQD">
                        </td>
                    </tr>
                    <tr>
                        <td>Tên</td>
                        <td>
                            <input type="text" name="TESP_DQD" id="TESP_DQD">
                        </td>
                    </tr>
                    <tr>
                        <td>Giá mua</td>
                        <td>
                            <input type="text" name="GIAMUA_DQD" id="GIAMUA_DQD">
                        </td>
                    </tr>
                    <tr>
                        <td>Giá bán</td>
                        <td>
                            <input type="text" name="GIABAN_DQD" id="GIABAN_DQD">
                        </td>
                    </tr>
                    <tr>
                        <td>Trạng thái</td>
                        <td>
                            <select name="TRANGTHAI_DQD" >
                                <option value="1" selected>Hoạt động</option>
                                <option value="0" selected>Không hoạt động</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td>Mã danh mục</td>
                        <td>
                        <input type="text" name="MADM_DQD" id="MADM_DQD">
                        </td>
                    </tr>
                    <tr>
                        <td></td>
                        <td>
                            <input type="reset" value="Làm lại" name="btnReset_DQD">
                        </td>
                    </tr>
                </tbody>
            </table>    
        </form>
        <a href="sanpham-list-DQD.php">Danh sách sản phẩm</a>
    </section>
</body>
</html>