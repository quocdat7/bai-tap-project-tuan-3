<?php
    $conn_dqd = new mysqli("localhost","root","","qlbh_dinhquocdatcntt3");
?>