<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Danh sách danh mục</title>
    <link rel="stylesheet" href="style.css"/>
</head>
<body>
    <?php
        include("ketnoi-dinhquocdat.php");
        $sql_dqd = "SELECT * FROM danhmuc_dqd WHERE 1=1";
        $result_dqd = $conn_dqd->query($sql_dqd);
        //Duyệt và hiển thị kết quả -> tbody
    ?>
    <section class="container">
        <h1>Danh sách sản phẩm</h1>
        <hr/>
        <a href="danhmuc-create-dqd.php" class="btn">Thêm mới sản phẩm</a>
        <table width="100%" border="1px">
            <thead>
                <tr>
                    <th>STT</th>
                    <th>Mã danh mục</th>
                    <th>Tên</th>
                    <th>Trạng thái</th>
                    <th>Chức năng</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    if($result_dqd->num_rows>0){
                        $stt=0;
                        while($row_dqd = $result_dqd->fetch_array()):
                        $stt++;
                ?>
                <tr>
                    <td><?php echo $stt;?></td>
                    <td><?php echo $row_dqd["MADM_dqd"];?></td>
                    <td><?php echo $row_dqd["TENDM_dqd"];?></td>
                    <td><?php echo $row_dqd["TRANGTHAI_dqd"];?></td>
                    <td>
                        <a href="danhmuc-edit-dqd.php?MADM_dqd=<?php echo $row_dqd["MADM_dqd"];?>">Sửa</a>|
                        <a href="danhmuc-list-dqd.php?MADM_dqd=<?php echo $row_dqd["MADM_dqd"];?>">Xóa</a>
                    </td>
                </tr>
                <?php
                    endwhile;
                }
                ?>
            </tbody>
        </table>
        <a href="danhmuc-create-dqd.php" class="btn">Thêm mới sản phẩm</a>
    </section>
    <?php
        if(isset($_GET["MADM_dqd"])){
            $proid_dqd = $_GET["MADM_dqd"];
            $sql_delete_dqd = "DELETE FROM DANHMUC_dqd where MADM_ID ='$MADM_dqd'";
            if($conn_dqd->query($sql_delete_dqd)){
                header("Location:danhmuc-list-dqd.php");
            }else{
                echo "<script> alert('lỗi xóa'; </script>";
            }
        }
    ?>
</body>
</html>