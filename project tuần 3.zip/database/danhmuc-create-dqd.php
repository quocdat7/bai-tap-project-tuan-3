<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thêm mới thông tin sản phẩm</title>
    <link rel="stylesheet" href="style.css"/>
</head>
<body>
    <?php
        include("ketnoi-dinhquocdat.php");
        $sql_pb_dqd = "SELECT * FROM danhmuc_dqd  WHERE 1=1";
        $res_pb_dqd = $conn_dqd->query($sql_pb_dqd);
        if(isset($_POST["btnSubmit_dqd"])){
            $MADM_dqd = $_POST["MADM_dqd"];
            $TENDM_dqd = $_POST["TENDM_dqd"];
            $TRANGTHAI_dqd = $_POST["TRANGTHAI_dqd"];
            $sql_check_dqd = "SELECT MADM_dqd FROM danhmuc_dqd WHERE MADM_dqd = 'MADM_dqd' ";
            $res_check_dqd = $conn_dqd->query($sql_check_dqd);
            if($res_check_dqd->num_rows>0){
                $error_message_dqd="Lỗi trùng khóa chính.";
            }
            $sql_insert_dqd = "INSERT INTO danhmuc_dqd ('MADM_dqd', 'TENDM_dqd', 'TRANGTHAI_dqd')";
            $sql_insert_dqd.="VALUES ('$MADM_dqd','$TENDM_dqd','$TRANGTHAI_dqd');";
            if($conn_dqd->query($sql_insert_dqd)){
                header("Location: danhmuc-lisT-dqd.php"); 
            }else{
                $error_message_dqd="Lỗi thêm mới". mysqli_error($conn_dqd);
            }
        }
        ?>
    <section class="container">
        <h1>Thêm mới thông tin sản phẩm</h1>
        <form name="frm_dqd" method="post" action="">
            <table border="1" width="100%" cellspacing="5" cellpadding="5">
                <tbody>
                    <tr>
                        <td>Mã danh mục</td>
                        <td>
                        <input type="text" name="MADM_dqd" id="MADM_dqd">
                        </td>
                    </tr>
                    <tr>
                        <td>Tên</td>
                        <td>
                            <input type="text" name="TENDM_dqd" id="TENDM_dqd">
                        </td>
                    </tr>
                    <tr>
                        <td>Trạng thái</td>
                        <td>
                            <select name="TRANGTHAI_dqd" >
                                <option value="1" selected>Hoạt động</option>
                                <option value="0" selected>Không hoạt động</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td></td>
                        <td>
                            <input type="reset" value="Làm lại" name="btnReset_dqd">
                        </td>
                    </tr>
                </tbody>
            </table>    
        </form>
        <a href="danhmuc-list-dqd.php">Danh sách sản phẩm</a>
    </section>
</body>
</html>