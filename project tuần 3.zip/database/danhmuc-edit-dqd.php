<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>bạn làm mới thông tin sản phẩm</title>
    <link rel="stylesheet" href="css/style.css"/>
</head>
<body>
    <?php
        include("ketnoi-dinhquocdat.php");
        if(isset($_GET["MADM_dqd"])){
            $MADM_dqd= $_GET["MADM_dqd"];
            $sql_edit_dqd= "SELECT * FROM danhmuc_dqd WHERE MADM_dqd='$MADM_dqd'";
            $result_edit_dqd = $conn_dqd->query($sql_edit_dqd);
            $row_edit_dqd = $result_edit_dqd->fetch_array();
        }else{
            header("Location: danhmuc-list-dqd.php");
        }
        $sql_pb_dqd = "SELECT * FROM danhmuc_dqd WHERE 1=1";
        $res_pb_dqd = $conn_dqd->query($sql_pb_dqd);
        $error_message_dqd ="";
        if(isset($_POST["btnSubmit_dqd"])){
            $MADM_dqd = $_POST["MADM_dqd"];
            $TENDM_dqd = $_POST["TENDM_dqd"];
            $TRANGTHAI_dqd = $_POST["TRANGTHAI_dqd"];
            $sql_update_dqd= "UPDATE danhmuc_dqd SET";
            $sql_update_dqd.="MADM_dqd='$MADM_dqd',";
            $sql_update_dqd.="TENDM_dqd='$TENDM_dqd',";
            $sql_update_dqd.="TRANGTHAI_dqd='$TRANGTHAI_dqd',";
            if($conn_dqd->query($sql_update_dqd)){
                header("Location: danhmuc-list-dqd.php"); 
            }else{
                $error_message_dqd="Lỗi sửa dữ liệu". mysqli_error($conn_dqd);
            }
        }
    ?>
    <section class="container">
        <h1>bạn khoa đang thêm mới thông tin sản phẩm</h1>
        <form name="frm_dqd" method="post" action="">
            <table border="1" width="100%" cellspacing="5" cellpadding="5">
                <tbody>
                    <tr>
                        <td>Mã danh mục</td>
                        <td>
                            <select name="MADM_dqd" id="MADM_dqd">
                                <?php
                                    while($row = $res_pb_dqd->fetch_array()):        
                                ?>
                                <option value="<?php echo $row["MADM_dqd"]?>"
                                <?php
                                    if($row["MADM_dqd"]==$row_edit_dqd["MADM_dqd"]){
                                        echo "selected";
                                    }
                                ?>
                                >
                                </option>
                                <?php
                                    endwhile;
                                ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td>Tên</td>
                        <td>
                            <input type="text" name="TENDM_dqd" id="TENDM_dqd"
                                value="<?php echo  $row_edit_dqd["TENDM_dqd"]?>">
                        </td>
                    </tr>
                    <tr>
                        <td>Trạng thái</td>
                        <td>
                            <select name="TRANGTHAI_dqd" >
                                <option value="1" <?php if($row_edit_dqd["TRANGTHAI_dqd"]==1){echo "selected";}?>>Hoạt động</option>
                                <option value="0" <?php if($row_edit_dqd["TRANGTHAI_dqd"]==0){echo "selected";}?>>Không hoạt động</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td></td>
                        <td>
                            <input type="submit" value="Thêm" name="btnSubmit_dqd">
                            <input type="reset" value="Làm lại" name="btnReset_dqd">
                        </td>
                    </tr>
                </tbody>
            </table>    
            <div>
                <?php echo $error_message_dqd;?>
            </div>
        </form>
        <a href="danhmuc-list-dqd.php">Danh sách sản phẩm</a>
    </section>
</body>
</html>